
import 'dart:ui';

import 'package:flutter/material.dart';

final primaryColor = Color(0xFF9EA700);

final whiteColor = Colors.white;

final backgroundColor = const Color(0xFFF5F5F5);

final secondaryColor = const Color(0xFF9EA700);

final blackColor =  Colors.black87;